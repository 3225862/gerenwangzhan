import { collection, config, fields, singleton } from '@keystatic/core';

const imageOptions = {
  directory: 'public/uploads/projects',
  publicPath: '/uploads/projects/',
};

export default config({
  storage: {
    // P0 local mode. P9 will switch this block to GitHub mode with server-only env vars.
    kind: 'local',
  },
  ui: {
    brand: { name: '个人网站内容管理' },
    navigation: ['projects', 'siteSettings'],
  },
  collections: {
    projects: collection({
      label: '测试项目',
      slugField: 'slug',
      path: 'src/content/projects/*',
      columns: ['title', 'status', 'featured', 'draft'],
      schema: {
        title: fields.text({
          label: '标题',
          validation: { isRequired: true, length: { min: 1, max: 120 } },
        }),
        slug: fields.slug({ name: { label: '项目标题' }, slug: { label: '网址标识' } }),
        summary: fields.text({
          label: '摘要',
          multiline: true,
          validation: { isRequired: true, length: { min: 1, max: 300 } },
        }),
        body: fields.text({ label: '正文', multiline: true }),
        coverImage: fields.image({
          label: '封面图片',
          description: '仅允许少量 jpg/png/webp 图片；单张建议不超过 2 MB。',
          ...imageOptions,
        }),
        status: fields.select({
          label: '项目状态',
          options: [
            { label: '计划中', value: 'planned' },
            { label: '进行中', value: 'active' },
            { label: '已完成', value: 'completed' },
            { label: '暂停', value: 'paused' },
          ],
          defaultValue: 'planned',
        }),
        featured: fields.checkbox({ label: '推荐项目', defaultValue: false }),
        sortOrder: fields.integer({ label: '排序', defaultValue: 0 }),
        publishedAt: fields.date({ label: '发布日期' }),
        draft: fields.checkbox({ label: '草稿', defaultValue: true }),
      },
    }),
  },
  singletons: {
    siteSettings: singleton({
      label: '网站设置',
      path: 'src/data/site-settings',
      schema: {
        siteName: fields.text({ label: '网站名称', defaultValue: '个人网站 P0 测试' }),
        defaultLanguage: fields.select({
          label: '默认语言',
          options: [{ label: '中文', value: 'zh' }],
          defaultValue: 'zh',
        }),
      },
    }),
  },
});

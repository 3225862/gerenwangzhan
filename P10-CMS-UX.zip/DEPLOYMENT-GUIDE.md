# 部署准备指南

当前项目为 Astro static build，适合部署到境外低成本静态托管。正式部署前需要网站所有者提供域名、GitHub 私人仓库、GitHub OAuth App 和部署平台账号；本项目不购买、不注册、不写入任何真实凭据。

## GitHub mode

复制 `.env.example`，填写 `KEYSTATIC_GITHUB_REPO`、`KEYSTATIC_GITHUB_CLIENT_ID`、`KEYSTATIC_GITHUB_CLIENT_SECRET` 等生产环境变量。Secret 只能放在部署平台服务端环境变量中，不能进入 Git 或前端。OAuth 回调地址必须使用部署平台提供的 HTTPS 域名，并与 GitHub App 配置完全一致。

## 构建

执行 `npm ci` 和 `npm run build`。生产静态前台不依赖 GitHub 运行时资源；后台 GitHub mode 仅在登录和保存内容时访问 GitHub。

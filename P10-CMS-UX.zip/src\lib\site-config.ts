export type SiteLanguage = 'zh' | 'ja' | 'en';

export type SiteNavItem = {
  label: string;
  href: string;
  languages?: SiteLanguage[];
};

export type SiteConfig = {
  siteName: string;
  description: string;
  defaultLanguage: SiteLanguage;
  availableLanguages: SiteLanguage[];
  navigation: SiteNavItem[];
  footerLinks: SiteNavItem[];
  contactEmail: string;
};

// P1 interface: future SiteSettings fields can replace these defaults without changing layouts.
export const siteConfig: SiteConfig = {
  siteName: '个人网站 P0 测试',
  description: '个人资料与想法的整理空间。（P2 占位内容）',
  defaultLanguage: 'zh',
  availableLanguages: ['zh', 'ja', 'en'],
  navigation: [
    { label: '首页', href: '/' },
    { label: '关于', href: '/about/' },
    { label: '关于我', href: '/about/' },
  ],
  footerLinks: [
    { label: '邮箱', href: 'mailto:hello@example.com' },
    { label: 'GitHub', href: 'https://github.com/' },
  ],
  contactEmail: 'hello@example.com',
};

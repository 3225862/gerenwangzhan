import { defineCollection } from 'astro:content';
import { glob } from 'astro/loaders';
import { projectSchema } from './lib/project-validation.js';
import { homepageSchema, profileSchema, siteSettingsSchema } from './lib/p2-models.js';
import type { ZodType } from 'zod';

const projects = defineCollection({
  loader: glob({ pattern: '**/*.yaml', base: './src/content/projects' }),
  schema: projectSchema,
});

const singleton = (pattern: string, schema: ZodType) =>
  defineCollection({ loader: glob({ pattern, base: './src/data' }), schema });
export const collections = {
  projects,
  siteSettings: singleton('site-settings.yaml', siteSettingsSchema),
  profile: singleton('profile.yaml', profileSchema),
  homepage: singleton('homepage.yaml', homepageSchema),
};

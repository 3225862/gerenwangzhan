import { defineConfig } from 'astro/config';
import keystatic from '@keystatic/astro';

export default defineConfig({
  integrations: [...(process.env.SKIP_KEYSTATIC === 'true' ? [] : [keystatic()])],
  output: 'static',
});

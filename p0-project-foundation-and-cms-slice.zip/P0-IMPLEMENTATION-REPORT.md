# P0 实施报告

## 版本

- Astro：7.0.7
- Keystatic：@keystatic/astro 5.2.0，@keystatic/core 0.5.51
- Node.js：v24.18.0
- npm：11.16.0
- 包管理器：npm，已生成 `package-lock.json`

## 已完成

- Astro 项目基础、严格 TypeScript、Prettier、ESLint、Vitest、环境变量模板和 README。
- Keystatic local mode；用户入口为 `/admin`，自动转到 `/keystatic`。
- Project collection 和 SiteSettings singleton。
- Project 字段：title、slug、summary、body、coverImage、status、featured、sortOrder、publishedAt、draft。
- YAML 内容保存到 `src/content/projects`，图片目录边界为 `public/uploads/projects`。
- 极简项目列表/详情页；只为验证链路，不是正式视觉页面。
- Astro 当前版本的 `glob` content loader，已验证 YAML 被正确读取。
- 草稿过滤、schema、slug、必填字段、图片字段和外部依赖检查。
- 生产构建自动跳过本地 Keystatic 后台路由，保留静态公开页面构建能力。

## 使用流程

1. 运行 `npm install`。
2. 运行 `npm run dev`。
3. 打开 `http://127.0.0.1:4321/admin`。
4. 在“测试项目”中新建或修改项目并保存。
5. 内容写入 `src/content/projects`，封面图片写入 `public/uploads/projects`。
6. 关闭“草稿”后，Astro 构建才会生成 `/projects/[slug]/`。

## 登录模式

当前是本地模式，不需要登录，仅适合本机开发。GitHub mode 尚未启用；后续需要私人仓库名、GitHub OAuth App、回调地址、部署平台环境变量和 GitHub 双重验证。真实密钥不得进入仓库或前端。

## 检查结果

- lint：通过。
- 类型检查：0 errors；Astro 新版 `astro:content` 的 `z` 导出有 12 个提示，不影响通过。
- 测试：1 个测试文件，3/3 通过。
- 外部禁止依赖检查：通过，检查 23 个文件。
- Astro build：通过，生成首页、`/admin` 入口页和已发布项目详情页。
- 草稿检查：通过，构建产物未出现“P0 草稿测试项目”，也未生成草稿详情页。
- 本地开发冒烟：根页 200，`/admin` 302 到 `/keystatic`，`/keystatic` 200。

## 已知风险与阻塞

- 当前 `.git` 目录已存在但不可写，`git init` 无法完成模板写入；没有删除或覆盖它。需要由网站所有者修复该目录权限或在确认后重新初始化 Git。
- P0 的 local mode 不能直接作为生产后台；P9 才切换 GitHub mode。
- P0 尚未实现真正图片尺寸/文件大小检测，只在 CMS 字段说明、文档和路径边界中记录；P6/P8 需要补充上传层或构建检查。
- P0 不处理 EXIF 清理，P8 再确定去定位信息策略。
- 当前没有办理 ICP，也不承诺中国大陆绝对稳定访问。

## 新阻塞问题

除上述现有 `.git` 权限问题外，没有新增必须由网站所有者立即决定的 P0 阻塞问题。

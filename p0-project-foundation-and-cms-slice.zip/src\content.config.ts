import { defineCollection, z } from 'astro:content';
import { glob } from 'astro/loaders';

const projects = defineCollection({
  loader: glob({ pattern: '**/*.yaml', base: './src/content/projects' }),
  schema: z.object({
    title: z.string().min(1).max(120),
    slug: z
      .string()
      .min(1)
      .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
    summary: z.string().min(1).max(300),
    body: z.string().default(''),
    coverImage: z.string().nullable().optional(),
    status: z.enum(['planned', 'active', 'completed', 'paused']).default('planned'),
    featured: z.boolean().default(false),
    sortOrder: z.number().int().default(0),
    publishedAt: z.coerce.date().nullable().optional(),
    draft: z.boolean().default(true),
  }),
});

export const collections = { projects };

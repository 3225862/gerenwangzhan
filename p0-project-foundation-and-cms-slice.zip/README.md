# 个人网站 P0

这是个人网站的 P0 基础与最小 CMS 垂直切片。当前目标是验证内容链路，不是正式网站页面。

## 启动后台

1. 在项目目录打开终端。
2. 第一次运行 `npm install`。
3. 运行 `npm run dev`。
4. 打开 `http://127.0.0.1:4321/admin`，它会进入 Keystatic 管理界面。

P0 是本地模式，不需要 GitHub 登录。正式上线前会在 P9 配置 GitHub mode；GitHub 密钥只能放在部署平台的环境变量中。

## 创建测试项目

在管理界面打开“测试项目”，新建项目并填写标题、网址标识、摘要、正文、状态、排序等字段，可上传一张 jpg、jpeg、png 或 webp 封面图。单张图片目标不超过 2 MB。保存后，内容会写入 `src/content/projects`，图片会写入 `public/uploads/projects`。

将“草稿”关闭后，项目才会出现在公开测试列表和详情页。公开测试页是 `/`，详情页是 `/projects/网址标识/`。

## 检查项目

```text
npm run lint
npm run check
npm run test
npm run check:external
npm run build
```

## 内容和安全边界

P0 不使用传统数据库，不上传可执行文件、HTML、脚本、压缩包、大型 PDF、Office 文件或视频，不提交 `.env` 和任何真实密钥。P0 的 local mode 仅适合本机开发，不应直接作为生产后台。

## 当前停止点

完成 P0 后停止。完整视觉设计、公共布局、正式首页、完整项目/文章系统、多语言、生产部署和对象存储迁移分别属于 P1-P9。

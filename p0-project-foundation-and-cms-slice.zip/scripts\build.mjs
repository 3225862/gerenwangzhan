import { spawnSync } from 'node:child_process';

const result = spawnSync('astro', ['build'], {
  stdio: 'inherit',
  shell: process.platform === 'win32',
  env: {
    ...process.env,
    ASTRO_TELEMETRY_DISABLED: '1',
    // Keystatic local mode is a development-only admin surface in P0.
    SKIP_KEYSTATIC: 'true',
  },
});

process.exit(result.status ?? 1);

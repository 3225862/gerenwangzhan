import { describe, expect, it } from 'vitest';
import { z } from 'zod';

const projectSchema = z.object({
  title: z.string().min(1).max(120),
  slug: z
    .string()
    .min(1)
    .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/),
  summary: z.string().min(1).max(300),
  body: z.string().default(''),
  coverImage: z.string().nullable().optional(),
  status: z.enum(['planned', 'active', 'completed', 'paused']).default('planned'),
  featured: z.boolean().default(false),
  sortOrder: z.number().int().default(0),
  publishedAt: z.coerce.date().nullable().optional(),
  draft: z.boolean().default(true),
});

describe('P0 project content rules', () => {
  it('accepts the minimum published project shape', () => {
    const result = projectSchema.safeParse({
      title: '测试项目',
      slug: 'test-project',
      summary: '用于验证 CMS 到 Astro 的最小内容链路。',
      body: '测试正文',
      coverImage: '/uploads/projects/test-project/cover.jpg',
      status: 'completed',
      featured: true,
      sortOrder: 1,
      publishedAt: '2026-07-13',
      draft: false,
    });
    expect(result.success).toBe(true);
  });

  it('rejects missing required fields and unsafe slugs', () => {
    expect(projectSchema.safeParse({ title: '', slug: '../secret', summary: '' }).success).toBe(
      false,
    );
  });

  it('filters drafts from public output', () => {
    const projects = [
      { draft: false, slug: 'published' },
      { draft: true, slug: 'draft' },
    ];
    expect(projects.filter((project) => !project.draft).map((project) => project.slug)).toEqual([
      'published',
    ]);
  });
});
